package com.example.flutter_cubit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
